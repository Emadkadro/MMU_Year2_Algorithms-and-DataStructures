﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADSPortEx4
{
    //Graph implementation for Assessed Exercise 4

    //Hints : 
    //Use lecture materials from Week 9A
    // and lab sheet 'Lab 9: Graphs Implementation' to aid with base implementation...

    //For 4B, review material from lecture 9B and lab 10 to aid with the implementation of these metrics

    //For 4C, see lecture 10A and lab 10 to aid with your traversal implementation

    //To address the last task for 4C, you can use BFS or DFS to as an idea of how to start off, but remember that we're only
    // interested in loot that can be obtained from the safest possible route, so we don't nessicarily need to find everything on the network as in
    // BFS and DFS!

    // - Adam.M 

    public class Graph<T> where T : IComparable
    {
        //Create a List of graph's nodes 
        private LinkedList<GraphNode<T>> nodes;

        public Graph()
        {//Constructor: Set the nodes to empty list
            nodes = new LinkedList<GraphNode<T>>();
        }

        //Functions for Task A: Add Node function
        public void AddNode(T id)
        {//Avoid duplication
            if (GetNodeByID(id) == null)
            {
                nodes.AddLast(new GraphNode<T>(id));
            }
            else
            {
                Console.WriteLine("Node is already existed");
            }
        }

        public GraphNode<T> GetNodeByID(T id)
        {
            //Loop through the graph
            foreach (GraphNode<T> currentNode in nodes)
            {//Compare the corrent Node to the the other by ID 
                if (currentNode.ID.CompareTo(id) == 0)
                {
                    return currentNode;
                }
            }
            return null; //No node with the ID provided
        }

        public void AddEdge(T from, T to)
        {
            //Create the edge between nodes
            GraphNode<T> node1 = GetNodeByID(from);
            GraphNode<T> node2 = GetNodeByID(to);
            //if both nodes existed 
            if (node1 != null && node2 != null)
            {//add the edge
                node1.AddEdge(node2);
            }
            else
            {
                Console.WriteLine("Missing Node: one of the nodes or both was not found in the graph!");
            }
        }

        public int NumNodes()
        {
            return nodes.Count; //used 'Count' functionality to count nodes in the graph
        }

        public int NumEdges()
        {
            int totalEdges = 0;
            foreach (GraphNode<T> currentNode in nodes)
            {//Counting the Nodes in each ajcList
                totalEdges += currentNode.GetAdjList().Count;
            }
            return totalEdges;
        }

        //Functions for Tsak B2: Add Edge with weight 
        public void AddWeightedEdge(T from, T to, int weight)
        {
            GraphNode<T> node1 = GetNodeByID(from);
            GraphNode<T> node2 = GetNodeByID(to);
            //if the nodes existed 
            if (node1 != null && node2 != null)
            {
                //Add the edge with weight
                node1.AddEdgeWithWeight(node2, weight);
            }
            else
            {
                Console.WriteLine($"One of the Nodes: {from} or {to} does not exist in the graph!");
            }
        }

        //B2: Implement AverageOutbound to calculate the average number of outbound edges across the network
        public double AverageOutbound()
        {
            //Handler if no nodes are available
            if (NumNodes() == 0)
            {
                return 0;
            }
            else //Calculate the avrage outbound 
            {
                return (double)NumEdges() / NumNodes();
            }
        }

        //B2: Implement AverageWeight to calculate the average weight of edges within the network.
        public double AverageWeight()
        {
            int totalEdges = 0;
            int totalWeight = 0;

            foreach (GraphNode<T> node in nodes)
            {
                //Get the total weight and edges for each node
                foreach (int weight in node.GetWeights())
                {
                    totalWeight += weight;
                    totalEdges++;
                }
            }
            if (totalEdges == 0)
            {  return 0; }
            else  //Calculate the Avrage Weight of nodes 
            {
                return (double)totalWeight / totalEdges;
            }
        }

        //B2: Implement GetAllAdjacencies to return all IDs of nodes that are adjacent to a node specified by ID.
        public List<T> GetAllAdjacencies(T id)
        {
            GraphNode<T> node = GetNodeByID(id);
            if (id == null)
            {
                return new List<T>(); //Empty List 
            }
            return new List<T>(node.GetAdjList()); //All the adjacencies 
        }

        //Functions for Task C1: BFS Traversal
        public void BFS(T startID, ref List<T> visited)
        {
            //Setting a starting node by its ID
            GraphNode<T> startNode = GetNodeByID(startID);
            if (startNode == null) return; //Handle if No starting node available

            //Create the Queue for BFS Traversal and Seen: to keep track of visited nodes
            Queue<GraphNode<T>> queue = new Queue<GraphNode<T>>();
            HashSet<T> seen = new HashSet<T>();

            //Starting the BFS: enqueuing the start node and set it as "Seen"
            queue.Enqueue(startNode);
            seen.Add(startID);

            while (queue.Count > 0) //while 'queue' is not empty
            {
                //Dequeue the nodes in the queue and add their ID to the visited list.
                GraphNode<T> current = queue.Dequeue();
                visited.Add(current.ID);

                //Loop through all unvisited neighbours of the current node
                foreach (T neighbor in current.GetAdjList())
                {
                    //Dequeue unvisited neighbours and add them to the 'Seen' list
                    if (!seen.Contains(neighbor))
                    {
                        queue.Enqueue(GetNodeByID(neighbor));
                        seen.Add(neighbor);
                    }
                }
            }
        }


        //Functions for Task C1: DFS Traversal
        public void DFS(T startID, ref List<T> visited)
        {
            //Creae startNode by ID
            GraphNode<T> startNode = GetNodeByID(startID);
            if (startNode == null) return;

            //Initialise a stack for DFS Traversal, Set Seen: to keep track of visited nodes
            Stack<GraphNode<T>> stack = new Stack<GraphNode<T>>();
            HashSet<T> seen = new HashSet<T>();

            //Using 'Puch' to start the DFS for the startNode into the stack and mark it as seen
            stack.Push(startNode);
            seen.Add(startID);

            while (stack.Count > 0) //while 'queue' is not empty
            {
                //Pop the nodes and add their ID to the visited list 
                GraphNode<T> current = stack.Pop();
                visited.Add(current.ID);

                //Loop through all unvisited of the current nde
                foreach (T neighbor in current.GetAdjList())
                {
                    //Push unvisited neighbours and add them to the 'Seen' list
                    if (!seen.Contains(neighbor))
                    {
                        stack.Push(GetNodeByID(neighbor));
                        seen.Add(neighbor);
                    }
                }
            }
        }

        //Functions for Task C2: BFS Traversal
        public void SafestRoute(T startID, ref List<T> visited)
        {
            //Creae startNode by ID
            GraphNode<T> startNode = GetNodeByID(startID);
            if (startNode == null) return;

            //Iniialise the priority Queue using sort set to process neighbors by weight
            SortedSet<(int weight, T ID)> SafestQueue = new SortedSet<(int weight, T ID)>();
            HashSet<T> seen = new HashSet<T>();

            foreach (T neighbor in startNode.GetAdjList())
            {
                //Create weights associated with edge
                LinkedList<int> weights = startNode.GetWeights();

                //Use the First weight value or max weight if weight is unavailable
                int weight;
                if (weights.Count > 0)
                {
                    weight = weights.First.Value;
                }
                else
                {
                    weight = int.MaxValue;
                }
                SafestQueue.Add((weight, neighbor));
            }
            //while not empty 
            while (SafestQueue.Count > 0)
            {
                //Extract the neighbour with minimum weight
                (int Weight, T ID) current = SafestQueue.Min;
                SafestQueue.Remove(current);

                //Visit the current and add its ID to the Seen list 
                if (!seen.Contains(current.ID))
                {
                    visited.Add(current.ID);
                    seen.Add(current.ID);
                }
            }
        }



        //Free space, use as needed

        public void RemoveEdge(T from, T to)
        {
            GraphNode<T> n1 = GetNodeByID(from);
            GraphNode<T> n2 = GetNodeByID(to);


            if (n1 != null & n2 != null)
            {
                n1.RemoveEdge(n2);
            }
            else
            {
                Console.WriteLine("Node/s not found in the graph. Cannot add the edge");
            }
        }

        // Check if a node exists in the graph
        public bool ContainsNode(T id)
        {
            // Checks if a node with the given id exists in the graph
            return GetNodeByID(id) != null;
        }
    }
}
