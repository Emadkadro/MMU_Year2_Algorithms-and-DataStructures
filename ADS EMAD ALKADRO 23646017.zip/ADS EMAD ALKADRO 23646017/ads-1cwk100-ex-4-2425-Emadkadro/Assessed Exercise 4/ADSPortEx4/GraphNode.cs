﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADSPortEx4
{
    //Task A2 
    //Graph node implementation for Assessed Exercise 2
    public class GraphNode<T>
    {
        //Attributes
        private T id;
        private LinkedList<T> adjList;
        private LinkedList<int> weights;

        //Constructors 
        public GraphNode(T id)
        {
            this.id = id;
            this.adjList = new LinkedList<T>();
            weights = new LinkedList<int>();
        }

        public T ID
        {
            get { return id; }
            set { id = value; }
        }

        //Implementation of the GraphNodes functionalities
        //Add Edge to the graph 
        public void AddEdge(GraphNode<T> to)
        {
            //prevent duplication edges between nodesin the adjList
            if (!adjList.Contains(to.id))
            {
                adjList.AddLast(to.id);
            }
        }

        //Remove Edge from the graph 
        public void RemoveEdge(GraphNode<T> to)
        {
            adjList.Remove(to.ID);
        }

        //Return the current the adjacency list 
        public LinkedList<T> GetAdjList()
        {
            return adjList;
        }
        public LinkedList<int> GetWeights()
        {
            return weights;
        }

        // Task B1 Adding the AddEdgeWithWeight functionality in
        //the GraphNode allowing a weight to be associated with each
        //edge in the graph. 
        public void AddEdgeWithWeight(GraphNode<T> to, int weight)
        {
            //prevent duplication edges
            if (!adjList.Contains(to.id))
            {
                adjList.AddLast(to.ID);
                weights.AddLast(weight);
            }
        }
    }
}
