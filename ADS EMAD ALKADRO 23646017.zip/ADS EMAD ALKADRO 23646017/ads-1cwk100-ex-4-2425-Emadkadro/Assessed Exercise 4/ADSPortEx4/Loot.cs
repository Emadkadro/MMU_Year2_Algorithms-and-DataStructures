﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADSPortEx4
{
    class Loot : IComparable
    {
        //Task A1: Completing the Loot class contains the variables, Constructors and CompareTo()

        // Required variables
        private string name;
        private double lootvalue;

        // Initialise Constructors
        public Loot(string name, double lootvalue)
        {
            this.name = name;
            this.lootvalue = lootvalue;
        }
        // Public access to the Name variable and assign value using 'Get' & 'Set'
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        // Public access to the LootValue variable and assign value using 'Get' & 'Set'
        public double LootValue
        {
            get { return lootvalue; }
            set { lootvalue = value; }
        }
        //Use the name as a unique value to compare items.
        public int CompareTo(object obj)
        {
            Loot other = (Loot)obj;
            return Name.CompareTo(other.Name);
        }
    }
}
