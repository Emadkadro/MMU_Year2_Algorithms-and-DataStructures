﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADSPortEx4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Creating a graph object for handling nodes and edges of the graph
            Graph<string> graph = new Graph<string>();


            //Create a Menu driven interface here so a user can interact with your implementations
            while (true)
            {
                //Task A3: 
                Console.Clear();
                Console.WriteLine("Welcome to the Heist Planning Graph!");
                Console.WriteLine("Please select an option:");
                Console.WriteLine("1. Add a node to the graph");
                Console.WriteLine("2. Add a edge to the graph");
                Console.WriteLine("3. Display the number of nodes");
                Console.WriteLine("4. Display the number of edges");
                //Task B2:
                Console.WriteLine("5. Add edge with weight to the graph");
                Console.WriteLine("6. Calculate average outbound edges");
                Console.WriteLine("7. Calculate average edge weight");
                Console.WriteLine("8. Get adjacencies for a node");
                //Task C2:
                Console.WriteLine("9. Apply BFS traversal");
                Console.WriteLine("10. Apply DFS traversal");
                Console.WriteLine("11. Find the safest route");
                Console.WriteLine("12. Exit");

                Console.Write("\nYour choice: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddNode(graph);
                        break;

                    case "2":
                        AddEdge(graph);
                        break;
                    case "3":
                        DisplayNumberNodes(graph);
                            break;
                    case "4":
                        DisplayNumberEdges(graph);
                        break;
                        //Task B3: Updating the user interface based on the requirments
                    case "5":
                        AddWeightedEdge(graph);
                        break;
                    case "6":
                        CalculateAverageOutboundEdge(graph);
                        break;
                    case "7":
                        CalculateAverageEdgeWeight(graph);
                        break;
                    case "8":
                        GetAdjacenciesForNode(graph);
                        break;
                    case "9":
                        PerformBFS(graph);
                        break;
                    case "10":
                        PerformDFS(graph);
                        break;
                    case "11":
                        FindSafestRoute(graph);
                        break;
                    case "12":
                        
                        Console.WriteLine("Goodbye!");
                        Console.ReadKey();
                        return;
                    default:
                        Console.WriteLine("Invalid choice! Press any key to try again...");
                        Console.ReadKey();
                        break;
                }
            }
        }

        //Case 1 Implementation: 
        // Method to adds a Node to the graph.
        static void AddNode(Graph<string> graph)
        {
            Console.Write("\nEnter the loot name: ");
            string nodeName = Console.ReadLine();
            graph.AddNode(nodeName);
            Console.WriteLine($"Node '{nodeName}' added successfully!");
            Console.ReadKey();
        }

        //Case 2 Implementation:
        // Method to adds an edge to the graph.
        static void AddEdge(Graph<string> graph)
        {
            Console.WriteLine("Please note that 'Add Edge' requires a vlaid existing node's names in the graph!");
            Console.Write("\nEnter the name of node to start the Edge from (From): ");
            string from = Console.ReadLine();
            Console.Write("Enter the name of the node of your destination (To): ");
            string to = Console.ReadLine();

            graph.AddEdge(from, to);
            Console.WriteLine($"Edge added from '{from}' to '{to}'. ");
            Console.ReadKey();
        }

        //Case 3 Implementation: 
        // Method to displays the number of nodes in the graph.
        static void DisplayNumberNodes(Graph<string> graph)
        {
            Console.WriteLine($"\nNumber of nodes in the graph: {graph.NumNodes()}");
            Console.ReadKey();
        }

        //Case 4 Implementation: 
        // Method to displays the number of Edges in the graph.
        static void DisplayNumberEdges(Graph<string> graph)
        {
            Console.WriteLine($"\nNumber of nodes in the graph: {graph.NumEdges()}");
            Console.ReadKey();
        }

        //Case 5 Implementation 
        // Method to adds a edge with weight to the graph.
        static void AddWeightedEdge(Graph<string> graph)
        {
            // Inform the user that a valid existing node is required.
            Console.Write("Please note that (Add_Edge) requires a valid existing node's name in the graph! ");

            // Prompt for the "from" node
            string from = "";
            while (true)
            {
                Console.Write("\nEnter the name of the node to start the Edge from (From): ");
                from = Console.ReadLine();

                if (graph.ContainsNode(from)) // Assuming graph has a method to check if the node exists
                    break;
                else
                    Console.WriteLine($"Node '{from}' does not exist. Please enter a valid node name.");
            }

            // Prompt for the "to" node
            string to = "";
            while (true)
            {
                Console.Write("Enter the name of the node of your destination (To): ");
                to = Console.ReadLine();

                if (graph.ContainsNode(to)) // Assuming graph has a method to check if the node exists
                    break;
                else
                    Console.WriteLine($"Node '{to}' does not exist. Please enter a valid node name.");
            }

            // Prompt for the weight of the edge, ensuring it's an integer between 1 and 10.
            int weight = 0;
            while (true)
            {
                Console.Write("Enter the weight of the edge between 1 and 10: ");
                string weightInput = Console.ReadLine();

                if (int.TryParse(weightInput, out weight) && weight >= 1 && weight <= 10)
                {
                    break; // If valid, break out of the loop
                }
                else
                {
                    Console.WriteLine("Invalid input. Enter a weight between 1 and 10.");
                }
            }
            // Add the weighted edge to the graph
            graph.AddWeightedEdge(from, to, weight);
            Console.WriteLine($"Weighted edge added from '{from}' to '{to}' with weight {weight}. Press any key to continue...");
            Console.ReadKey();
        }

        //Case 6 Implementation 
        // Calculates and displays the average outbound edges.
        static void CalculateAverageOutboundEdge(Graph<string> graph)
        {
            Console.WriteLine($"\nAverage number of outbound edges: {graph.AverageOutbound()}");
            Console.ReadKey();
        }

        //Case 7 Implementation 
        // Method to calculates and displays the average edge weight in the graph.
        static void CalculateAverageEdgeWeight(Graph<string> graph)
        {
            Console.WriteLine($"\nAverage edge weight: {graph.AverageWeight()}");
            Console.ReadKey();
        }

        ////Case 8 Implementation 
        // Retrieves and displays all adjacencies for a specified node.
        static void GetAdjacenciesForNode(Graph<string> graph)
        {
            Console.Write("\nEnter the node's name: ");
            string nodeName = Console.ReadLine();
            List<string> adjacencies = graph.GetAllAdjacencies(nodeName);

            if (adjacencies.Count > 0)
            {
                Console.WriteLine($"Nodes adjacent to '{nodeName}': {string.Join(", ", adjacencies)}");
                foreach (var adj in adjacencies)
                {
                    Console.WriteLine(adj);
                }
            }
            else
            {
                Console.WriteLine($"No adjacencies found for '{nodeName}' or node does not exist.");
            }
            Console.ReadKey();
        }

        //Case 9 Implementation 
        // Method to performs BFS (Breadth-First Search) traversal on the graph.
        static void PerformBFS(Graph<string> graph)
        {
            Console.Write($"\nEnter the starting node for BF Search: ");
            string startNode = Console.ReadLine();

            List<string> visited = new List<string>();
            graph.BFS(startNode, ref visited);
            
            Console.WriteLine("BFS traversal order: ");
            foreach(var node in visited)
            {
                Console.WriteLine(node); 
            }
            Console.ReadKey();
        }

        //Case 10 Implementation
        // Method to performs DFS (Depth-First Search) traversal on the graph.
        static void PerformDFS(Graph<string> graph)
        {
            Console.Write($"\nEnter the starting node for DF Search: ");
            string startNode = Console.ReadLine();

            List<string> visited = new List<string>();
            graph.DFS(startNode, ref visited);

            Console.WriteLine("\nDFS traversal order: ");
            foreach (var node in visited)
            {
                Console.WriteLine(node);
            }
            Console.ReadKey();
        }

        //Case 11 Implementation 
        // Method to find the safest route in the graph
        static void FindSafestRoute(Graph<string> graph)
        {
            Console.Write("Enter the starting node for finding the safest route: ");
            string startNode = Console.ReadLine();

            List<string> visited = new List<string>();
            graph.SafestRoute(startNode, ref visited);

            Console.WriteLine("Safest Route Traversal:");
            foreach (var node in visited)
            {
                Console.WriteLine(node);
            }
            Console.ReadKey();
        }
    }
}
