﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace ADSPortEx1
{
    partial class frmGest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        /// 


        private System.ComponentModel.IContainer components = null;
        private Label labTitle;
        private Label labSubTitle;
        private Label lblReverseNote;
        private Label labNumItems;
        private Label labHeadQueue;
        private Label labFunds;
        private Label label1;
        private Label labPeek;
        private Label labNumItem;
        private Button btnRemove;
        private Button btnGetMostFunds;
        private Button btnReverse;
        private Button btnAdd;
        private TextBox txtReverseNum;
        private TextBox txtFunds;
        private TextBox txtName;
        private ListBox listBoxGuests;
        private Label lblMostFunds;




        private void InitializeComponent()
        {
            this.labTitle = new System.Windows.Forms.Label();
            this.labSubTitle = new System.Windows.Forms.Label();
            this.lblReverseNote = new System.Windows.Forms.Label();
            this.labNumItems = new System.Windows.Forms.Label();
            this.labHeadQueue = new System.Windows.Forms.Label();
            this.labFunds = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labPeek = new System.Windows.Forms.Label();
            this.labNumItem = new System.Windows.Forms.Label();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnGetMostFunds = new System.Windows.Forms.Button();
            this.btnReverse = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtReverseNum = new System.Windows.Forms.TextBox();
            this.txtFunds = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.listBoxGuests = new System.Windows.Forms.ListBox();
            this.lblMostFunds = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labTitle
            // 
            this.labTitle.AutoSize = true;
            this.labTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labTitle.Location = new System.Drawing.Point(12, 9);
            this.labTitle.Name = "labTitle";
            this.labTitle.Size = new System.Drawing.Size(400, 31);
            this.labTitle.TabIndex = 11;
            this.labTitle.Text = "Theme Park Ride Guest Form";
            // 
            // labSubTitle
            // 
            this.labSubTitle.AutoSize = true;
            this.labSubTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labSubTitle.Location = new System.Drawing.Point(12, 47);
            this.labSubTitle.Name = "labSubTitle";
            this.labSubTitle.Size = new System.Drawing.Size(679, 17);
            this.labSubTitle.TabIndex = 12;
            this.labSubTitle.Text = "Please enter each guest’s name, available funds, and total number of guests to ad" +
    "d them to the queue list.";
            // 
            // lblReverseNote
            // 
            this.lblReverseNote.AutoSize = true;
            this.lblReverseNote.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReverseNote.Location = new System.Drawing.Point(760, 522);
            this.lblReverseNote.Name = "lblReverseNote";
            this.lblReverseNote.Size = new System.Drawing.Size(389, 17);
            this.lblReverseNote.TabIndex = 24;
            this.lblReverseNote.Text = "Add the position number you want to move the first Guest to.";
            // 
            // labNumItems
            // 
            this.labNumItems.AutoSize = true;
            this.labNumItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labNumItems.Location = new System.Drawing.Point(0, 238);
            this.labNumItems.Name = "labNumItems";
            this.labNumItems.Size = new System.Drawing.Size(624, 17);
            this.labNumItems.TabIndex = 23;
            this.labNumItems.Text = "Please note that You are only allowed to add a maximum of 10 guests. Current Numb" +
    "er of Guests:";
            // 
            // labHeadQueue
            // 
            this.labHeadQueue.AutoSize = true;
            this.labHeadQueue.BackColor = System.Drawing.Color.SkyBlue;
            this.labHeadQueue.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labHeadQueue.Location = new System.Drawing.Point(0, 264);
            this.labHeadQueue.Name = "labHeadQueue";
            this.labHeadQueue.Size = new System.Drawing.Size(250, 17);
            this.labHeadQueue.TabIndex = 22;
            this.labHeadQueue.Text = "Nmae the head of the queued Guests:";
            // 
            // labFunds
            // 
            this.labFunds.AutoSize = true;
            this.labFunds.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labFunds.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labFunds.Location = new System.Drawing.Point(412, 80);
            this.labFunds.Name = "labFunds";
            this.labFunds.Size = new System.Drawing.Size(136, 24);
            this.labFunds.TabIndex = 21;
            this.labFunds.Text = "Guest\'s Funds ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(24, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 24);
            this.label1.TabIndex = 20;
            this.label1.Text = "Name of Guest";
            // 
            // labPeek
            // 
            this.labPeek.AutoSize = true;
            this.labPeek.BackColor = System.Drawing.Color.White;
            this.labPeek.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labPeek.Location = new System.Drawing.Point(268, 264);
            this.labPeek.Name = "labPeek";
            this.labPeek.Size = new System.Drawing.Size(64, 18);
            this.labPeek.TabIndex = 25;
            this.labPeek.Text = "\"Name\"";
            // 
            // labNumItem
            // 
            this.labNumItem.AutoSize = true;
            this.labNumItem.BackColor = System.Drawing.Color.White;
            this.labNumItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labNumItem.ForeColor = System.Drawing.Color.Black;
            this.labNumItem.Location = new System.Drawing.Point(630, 238);
            this.labNumItem.Name = "labNumItem";
            this.labNumItem.Size = new System.Drawing.Size(19, 20);
            this.labNumItem.TabIndex = 26;
            this.labNumItem.Text = "0";
            // 
            // btnRemove
            // 
            this.btnRemove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemove.ForeColor = System.Drawing.Color.Maroon;
            this.btnRemove.Location = new System.Drawing.Point(381, 175);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(223, 37);
            this.btnRemove.TabIndex = 30;
            this.btnRemove.Text = "Remove guest -";
            this.btnRemove.UseVisualStyleBackColor = false;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnGetMostFunds
            // 
            this.btnGetMostFunds.BackColor = System.Drawing.Color.Green;
            this.btnGetMostFunds.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGetMostFunds.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnGetMostFunds.Location = new System.Drawing.Point(750, 314);
            this.btnGetMostFunds.Name = "btnGetMostFunds";
            this.btnGetMostFunds.Size = new System.Drawing.Size(226, 42);
            this.btnGetMostFunds.TabIndex = 29;
            this.btnGetMostFunds.Text = "£ Get Most Funds";
            this.btnGetMostFunds.UseVisualStyleBackColor = false;
            this.btnGetMostFunds.Click += new System.EventHandler(this.btnGetMostFunds_Click);
            // 
            // btnReverse
            // 
            this.btnReverse.BackColor = System.Drawing.Color.IndianRed;
            this.btnReverse.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReverse.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnReverse.Location = new System.Drawing.Point(750, 421);
            this.btnReverse.Name = "btnReverse";
            this.btnReverse.Size = new System.Drawing.Size(233, 42);
            this.btnReverse.TabIndex = 28;
            this.btnReverse.Text = "< Reverse";
            this.btnReverse.UseVisualStyleBackColor = false;
            this.btnReverse.Click += new System.EventHandler(this.btnReverse_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAdd.Location = new System.Drawing.Point(9, 175);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(226, 42);
            this.btnAdd.TabIndex = 27;
            this.btnAdd.Text = "Add to the list +";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtReverseNum
            // 
            this.txtReverseNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReverseNum.Location = new System.Drawing.Point(687, 515);
            this.txtReverseNum.Name = "txtReverseNum";
            this.txtReverseNum.Size = new System.Drawing.Size(52, 26);
            this.txtReverseNum.TabIndex = 33;
            // 
            // txtFunds
            // 
            this.txtFunds.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFunds.Location = new System.Drawing.Point(417, 112);
            this.txtFunds.Name = "txtFunds";
            this.txtFunds.Size = new System.Drawing.Size(146, 27);
            this.txtFunds.TabIndex = 32;
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(24, 112);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(352, 27);
            this.txtName.TabIndex = 31;
            // 
            // listBoxGuests
            // 
            this.listBoxGuests.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxGuests.FormattingEnabled = true;
            this.listBoxGuests.ItemHeight = 20;
            this.listBoxGuests.Location = new System.Drawing.Point(4, 300);
            this.listBoxGuests.Name = "listBoxGuests";
            this.listBoxGuests.Size = new System.Drawing.Size(654, 244);
            this.listBoxGuests.TabIndex = 34;
            // 
            // lblMostFunds
            // 
            this.lblMostFunds.AutoSize = true;
            this.lblMostFunds.BackColor = System.Drawing.Color.White;
            this.lblMostFunds.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostFunds.Location = new System.Drawing.Point(683, 367);
            this.lblMostFunds.Name = "lblMostFunds";
            this.lblMostFunds.Size = new System.Drawing.Size(0, 17);
            this.lblMostFunds.TabIndex = 35;
            // 
            // frmGest
            // 
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(1232, 578);
            this.Controls.Add(this.lblMostFunds);
            this.Controls.Add(this.listBoxGuests);
            this.Controls.Add(this.txtReverseNum);
            this.Controls.Add(this.txtFunds);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnGetMostFunds);
            this.Controls.Add(this.btnReverse);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.labNumItem);
            this.Controls.Add(this.labPeek);
            this.Controls.Add(this.lblReverseNote);
            this.Controls.Add(this.labNumItems);
            this.Controls.Add(this.labHeadQueue);
            this.Controls.Add(this.labFunds);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labSubTitle);
            this.Controls.Add(this.labTitle);
            this.Name = "frmGest";
            this.Text = "Guest Form";
            this.Load += new System.EventHandler(this.FrmGest_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}