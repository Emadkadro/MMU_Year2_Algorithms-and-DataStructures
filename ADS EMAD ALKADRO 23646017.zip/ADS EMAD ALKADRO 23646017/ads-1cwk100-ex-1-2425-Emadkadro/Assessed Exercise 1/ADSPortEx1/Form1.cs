﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Lifetime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace ADSPortEx1
{
    public partial class frmGest : Form
    {
        // Provide access to the class's functions 
        GuestQueue guestQueue = new GuestQueue();

        public frmGest()
        {
            InitializeComponent();
        }

        private void FrmGest_Load(object sender, EventArgs e)
        {

        }

        //Add Guest to the queue
        private void btnAdd_Click(object sender, EventArgs e)
        {
            //Add the needed variables with Trim() for validation
            string name = txtName.Text.Trim();
            double funds;

            //Validate the Name's input
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Please enter a valid name", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            //Validate the funds input
            if (!double.TryParse(txtFunds.Text, out funds) || funds <= 0)
            {
                MessageBox.Show("Please enter a valid number for funds.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //Add to the list button
            for (int i = 0; i < 1; i++)
            {
                //Check if Queue is NOT full
                if (!guestQueue.IsFull())
                {//Add guest details to the queue
                    Guest newGuest = new Guest(name, funds);
                    guestQueue.Enqueue(newGuest);
                }
                else
                {
                    MessageBox.Show("The queue is full. Cannot add more guests.", "Queue Full", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    break;
                }
            }

            //Updates
            // Update the ListBox to showing the current guests
            UpdateGuestList();
            //Update the current number of Guests when Adding 
            UpdateGuestCountLabel();
            //Update the current Head of Guests when Adding 
            UpdateHeadGuestLabel();

            // Clear the input fields after adding guests
            txtName.Clear();
            txtFunds.Clear();
            // Set focus back to the name input for convenience
            txtName.Focus();
        }

        //Remove Guest from the queue
        private void btnRemove_Click(object sender, EventArgs e)
        {
            //Handler: User should not remove if the Queue is empty
            if (guestQueue.IsEmpty())
            {
                MessageBox.Show("The queue is empty.", "Queue Empty", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //Dequeue guest from the list
            Guest removedGeste = guestQueue.Dequeue();

            //Ensure that Guest will be removed with worning
            MessageBox.Show($"Removed Guest Name: {removedGeste.Name}, Funds: {removedGeste.Funds}", "Guest Removed", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //Updates
            // Update the ListBox to showing the remaining guests
            UpdateGuestList();
            //Update the current number of Guests when removing 
            UpdateGuestCountLabel();
            //Update the current Head of Guests when Adding 
            UpdateHeadGuestLabel();
        }

        //Get the most Funds Button 
        private void btnGetMostFunds_Click(object sender, EventArgs e)
        {
            //First, add handler if there are no funds to display
            if (guestQueue.IsEmpty())
            {
                MessageBox.Show("The queue is empty no funds to return.", "Queue Empty", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //Getting the guest with the most funds 
            Guest mostFundsGuest = guestQueue.GetMostFunds();

            //Display the guest with the most funds using the label
            lblMostFunds.Text = $"Guest with the most funds: {mostFundsGuest.Name}, Funds: £{mostFundsGuest.Funds}";
        }

        // Reverce button 
        private void btnReverse_Click(object sender, EventArgs e)
        {
            //k value validation
            int k;
            if (!int.TryParse(txtReverseNum.Text, out k) || k > guestQueue.Count())
            {
                MessageBox.Show("Please enter a valid number of guests to reverse, and insure queue is not empty", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //Reverse the first k guests in the queue
            guestQueue.Reverse(k);

            //Update Display.
            UpdateGuestList();
            UpdateHeadGuestLabel();
        }

        //-------------------------------- ADDITIONAL METHODS ------------------------------------------------------------------------------------------------------- 



        //Adding the Update List Function
        private void UpdateGuestList()
        {
            // Clear all items from the guest list box to prepare for an updated list
            listBoxGuests.Items.Clear();
            // Loop through each guest in the guest queue
            for (int i = 0; i < guestQueue.Count(); i++)
            {
                Guest guest = guestQueue.Peek(); // Peek at the first guest in the queue without removing it
                guestQueue.Enqueue(guestQueue.Dequeue()); // Move the first guest to the end of the queue to cycle through the queue
                // Add the guest information to the list box
                listBoxGuests.Items.Add($"Name: {guest.Name}, Funds: {guest.Funds}");
            }
        }

        private void UpdateGuestCountLabel()
        {
            // Update the label to show the current number of guests in the queue
            labNumItem.Text = $"Current Number of Guests: {guestQueue.Count()}";
        }

        private void UpdateHeadGuestLabel()
        {// Check if the guest queue is empty
            if (guestQueue.IsEmpty())
            {
                labPeek.Text = "the Queue is empty. The current Guest's Head of the queue: None";
            }
            else
            {
                // Not empty, get the current head guest
                Guest headGuest = guestQueue.Peek();
                labPeek.Text = $"The current Guest's Head of the queue: {headGuest.Name}";
            }
        }
    }
}
