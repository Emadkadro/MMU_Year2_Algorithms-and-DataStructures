﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADSPortEx1
{

    class Guest : IComparable
    {
        //Adding the variables 
        private string name;
        private double funds;
        // Constructor to initialise the Guest object with a name and funds
        public Guest(string name, double funds)
        {
            this.name = name;
            this.funds = funds;
        }
        // Property for accessing and modifying the guest's name
        public string Name
        {
            get { return name; }
            set { name=value; }
        }
        // Property for accessing and modifying the guest's available funds
        public double Funds
        {
            get { return funds; }
            set { funds=value; }
        }
        //compare two Guest objects based on their names
        // It helps in sorting or ordering Guest objects by name
        public int CompareTo(object obj)
        {
            Guest other = obj as Guest;
            return Name.CompareTo(other.Name);
        }
    }
}
