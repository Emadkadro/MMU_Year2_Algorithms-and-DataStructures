﻿using System;
using System.Collections.Generic;

namespace ADSPortEx1
{

    class GuestQueue
    {
        //Adding the variables 
        private int maxSize = 10; // Maximum queue size 
        private Guest[] store; // Array to store guests objects
        private int head = 0; //The index of the queue's head
        private int tail = 0; //The index of the queue's tail
        private int numItems; //Current number of guests in the queue

        // Property for accessing and modifying the guest's store 
        public GuestQueue()
        {
            store = new Guest[maxSize];
        }
        // Property for accessing and modifying the guest's queue 
        public GuestQueue(int size)
        {
            maxSize = size;
            store = new Guest[maxSize];
        }

        // Enqueue guest functionality 
        public void Enqueue(Guest value)
        {
            //Handle if is full and message the user
            if (IsFull())
            {
                throw new InvalidOperationException("Queue is full.");
            }
            store[tail] = value;     // Add the new guest to the position indicated by the tail pointer
            tail++;                 // Move the tail pointer to the next position
            numItems++;             // Increase the count of items in the queue
            //Rest the tail to 0 if it reached the end
            if (tail == maxSize)
            {
                tail = 0;
            }
        }

        // Dequeue guest functionality 
        public Guest Dequeue()
        {
            //Handle if is empty 
            if (IsEmpty())
            {
                throw new InvalidOperationException("Queue is empty.");
            }
            Guest headItem = store[head];// Retrieve the item at the head of the queue
            head++;         // Move the head pointer to the next position
            numItems--;     // Reduce the count of items in the queue
            //Rest head if it has reached the maxSize
            if (head == maxSize)
            {
                head = 0;
            }
            return headItem;
        }

        //Return the head of the queue 
        public Guest Peek()
        {
            return store[head];
        }

        // Return the number of the guests 
        public int Count()
        {
            return numItems;
        }

        // Returen empty queue
        public bool IsEmpty()
        {
            return numItems == 0;
        }

        // Return full queue
        public bool IsFull()
        {
            return numItems == maxSize;
        }

        //Allow for the first k number of guests to be reversed in the queue. 
        public void Reverse(int k)
        {
            //Handle if k was not within the number of elements in the queue
            if (k > numItems || k <= 0)
            {
                throw new ArgumentOutOfRangeException("Invalid k value");
            }
            //Create a temporary queue to store the k elements
            Stack<Guest> temporaryQueue = new Stack<Guest>();

            // Dequeue the first k elements to be stored in temporaryQueue
            for (int i = 0; i < k; i++)
            {
                temporaryQueue.Push(Dequeue());
            }
            // Re-enqueue the reversed first k elements from the stack
            while (temporaryQueue.Count > 0)
            {
                Enqueue(temporaryQueue.Pop());
            }
            // Calculate the number of remaining items in the queue
            int remainingItems = numItems - k;
            // Re-enqueue the remaining elements to maintain their original order
            for (int i = 0; i < remainingItems; i++)
            {
                Enqueue(Dequeue());
            }
        }

        // Return the guest who possesses the most funds. 
        public Guest GetMostFunds()
        {
            if (IsEmpty())
            {   // Check if the queue is empty and throw an exception
                throw new InvalidOperationException("Empty Queue");
            }

            // Set a starting point head of the queue.
            Guest mostFundsGuest = store[head];

            // Start checking from the head and go until the tail
            for (int i = 0; i < numItems; i++)
            {
                // Calculate the current index in the circular buffer
                int index = head + i;

                // Wrap around the index if it exceeds the maximum size of the buffer
                if (index >= maxSize)
                {
                    index -= maxSize; // Reset the index to start from 0
                }

                // Compare the current guest's funds with the current maximum
                if (store[index].Funds > mostFundsGuest.Funds)
                {   // Update the guest with the highest funds
                    mostFundsGuest = store[index];
                }
            }
            return mostFundsGuest; // Return the guest with the most funds
        }
    }
}
